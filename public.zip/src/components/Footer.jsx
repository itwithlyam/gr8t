import React from "react";
import './styles.css'

function Footer() {
  return (
    <div className="footer">
      <p className="m-0 text-center text-white">
        Copyright &copy; Gr8t 2022
      </p>
    </div>
  );
}

export default Footer;